import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {
       
        double[] y={7,5,6,3,4,2.6,2,0.6};
        
        double[] x={1,2,3,4,5,6,7,8};

        double m=pendiente(x, y);

        double b=b(x,y,m);

        String mensaje=String.format("Y= %fX + %f", m,b);
        
        JOptionPane.showMessageDialog(null , mensaje);
        
        


    }


    public static double pendiente(double[] x,double[] y){
        double pendient=0;
        if (x.length==y.length){
            double sumaX=0;
            double sumaY=0;
            double sumaXY=0;
            double sumaX2=0;
            int n=y.length;


            for (int i = 0; i < n; i++) {

                double xi=x[i];
                double yi=y[i];
                sumaX+=xi;
                sumaY+=yi;
                sumaXY+=xi*yi;
                sumaX2+=xi*xi;
            }

            pendient= (n*sumaXY-(sumaX*sumaY))/(n*sumaX2-(sumaX*sumaX));
        }  

        return pendient;
    }

    public static double b(double[] x,double[] y, double m) {
        
        double sumaX=0;
        double sumaY=0;
        for (int i = 0; i < x.length; i++) {
            sumaX+=x[i];
            sumaY+=y[i];
        }

        int n=x.length;

        double b=(sumaY/n)-m*(sumaX/n);
        return b;
    }

    

}
