
import os
import numpy
from numpy import *


def matInv(A):
        
    
   
    print (A.I)                                    
    




A=matrix([ [1,0,-1],
    [2,0,2],
    [8,2,-3]])

os.system('cls')

print("La matriz es:")
print(A)

print("La inversa de la matriz es:")
print(matInv(A))
