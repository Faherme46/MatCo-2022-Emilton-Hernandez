package Parcial_3.Ejercicio_4.src;
import javax.swing.JOptionPane;

public class App {



    public static void main(String[] args) throws Exception {
       
        double[] y={7.5,8,8.5,9.2,9.9,10.5,11.5,12.2};
        double lny[]=new double[8];
        for (int i = 0; i < y.length; i++) {
            
            lny[i]=Math.log(y[i]);
        }

        double logy[]=new double[8];
        for (int i = 0; i < y.length; i++) {
            
            logy[i]=Math.log(y[i]);
        }

               
        double[] x={1,2,3,4,5,6,7,8};

        double m=pendienteExponencial(x, lny);

        double b=a0Exponencial(x,lny,m);



        String mensaje=String.format("Por el modelo exponencial: \nln(y)= %.3fX + %.3f", m,b);
        
        JOptionPane.showMessageDialog(null , mensaje);
        
        


    }


    public static double pendienteExponencial(double[] x,double[] y){

        double a1=0;

        if (x.length==y.length){
            double sumaX=0;
            double sumaY=0;
            double sumaXY=0;
            double sumaX2=0;
            int n=y.length;


            for (int i = 0; i < n; i++) {

                double xi=x[i];
                double yi=y[i];

                sumaX+=xi;
                sumaY+=yi;
                sumaXY+=xi*yi;
                sumaX2+=xi*xi;
            }

            a1= (n*sumaXY-(sumaX*sumaY))/(n*sumaX2-(sumaX*sumaX));
        }  

        return a1;
    }

    public static double a0Exponencial(double[] x,double[] y, double m) {
        
        double sumaX=0;
        double sumaY=0;
        for (int i = 0; i < x.length; i++) {
            sumaX+=x[i];
            sumaY+=y[i];
        }

        int n=x.length;

        double b=(sumaY/n)-m*(sumaX/n);

        double alfa= Math.exp(b);

        return Math.log(alfa);
    }

    public static double pendientePotencias(double[] x,double[] y){

        double a1=0;

        if (x.length==y.length){
            double sumaX=0;
            double sumaY=0;
            double sumaXY=0;
            double sumaX2=0;
            int n=y.length;


            for (int i = 0; i < n; i++) {

                double xi=x[i];
                double yi=y[i];

                sumaX+=xi;
                sumaY+=yi;
                sumaXY+=xi*yi;
                sumaX2+=xi*xi;
            }

            a1= (n*sumaXY-(sumaX*sumaY))/(n*sumaX2-(sumaX*sumaX));
        }  

        return a1;
    }

    public static double a0Potencias(double[] x,double[] y, double m) {
        
        double sumaX=0;
        double sumaY=0;
        for (int i = 0; i < x.length; i++) {
            sumaX+=x[i];
            sumaY+=y[i];
        }

        int n=x.length;

        double b=(sumaY/n)-m*(sumaX/n);

        double alfa= Math.exp(b);

        return Math.log(alfa);
    }

    


}