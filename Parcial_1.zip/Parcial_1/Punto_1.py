import os 

#funciones


B=set()
A=set()
C=set()
D=set()
x=0


B={0,2,4,6,12,24,48}
D={2,3,5,7,11,13,17,19,23,29,31,37}
#llenar a
for i in range(10,30,1):
    A.add(i)

#llenar c
    for i in range(0,45,1):
        if (i%4 ==2):
            C.add(i)
            



menu=["Operacion 1","Operacion 2","Operacion 3","Ver Conjuntos","SALIR" ]
def noValida():

    os.system('cls')
    print("Opcion no valida, intente nuevamente")
    

def tryInt(txt:str):#metodo para leer datos enteros
    isTry=True
    while isTry:
        try:
            x=int(input(txt))
        except:
            print("No es valido, ingrese nuevamente el dato")
            os.system('pause')
        else:
            isTry=False
            return x

    
def verMenu():
    
    os.system('cls')
    print("*****MENU PRINCIPAL*****")
    for i in range(len(menu)):
        print(f"{i+1}. {menu[i]}" )

def opcionElegida(opc):
    os.system('cls')
    result=True
    global x
    
    if opc=="1":
        d=diferenciaAB(A,C)
        i=interseccion(B,D)

        r=simetrica(d,i)
        print("El resultado de la Operacion 1 es: ",r)
        print("Cardinalidad: ",len(r))

    elif opc=="2":
        i=interseccion(B,D)
        s=simetrica(i,C)
        u=union(A,D)
        r=diferenciaAB(s,u)

        print("El resultado de la Operacion 2 es: ",r)
        print("Cardinalidad: ",len(r))
        
    elif opc=="3":

        i=interseccion(A,interseccion(B,C))
        d1=diferenciaAB(A,C)
        d2=diferenciaAB(B,D)
        u1=union(d1,d2)
        r=union(i,u1)

        print("El resultado de la Operacion 3 es: ",r)
        print("Cardinalidad: ",len(r))
    elif opc=="4":
        print("A: ",A)
        print("B: ",B)
        print("C: ",C)
        print("D: ",D)

    elif opc=="5":
        result=bool(input("S para salir, ENTER para no salir\n"))
    else:
        noValida()
    
    return result   


#operaciones



def union(A:set,B:set):
    c=set()
    for i in A:
        c.add(i)
    for i in B:
        c.add(i)
    
    return c

def interseccion(A:set,B:set):
    c=set()
    for i in A:
        if i in B:
            c.add(i)
    
    return c

def diferenciaAB(A:set,B:set):
    c=set()
    for i in A:
        if not(i in B):
            c.add(i)
    
    return c

def diferenciaBA(A:set,B:set):
    c=set()
    for i in B:
        if not(i in A):
            c.add(i)
    
    return c

def simetrica(A:set,B:set):
    c=set()
    e=union(A,B)
    d=interseccion(A,B)
    for i in e:
        if not(i in d):
            c.add(i)
    return c

#main




isActive=True
while isActive:
    verMenu()
    isActive=opcionElegida(input(":)"))
    os.system('pause')