import os


def tryInt(txt:str):#metodo para leer datos enteros
    isTry=True
    while isTry:
        try:
            x=int(input(txt))
        except:
            print("No es valido, ingrese nuevamente el dato")
            os.system('pause')
        else:
            isTry=False
            return x


#numero=tryInt("Ingrese el numero decimal para convertir a hexadecimal")
def pasaraHexa(numero):
    os.system('cls')
    
    numero=str(numero)
    lista=[]
    for i in numero:
        lista.append(i)
    lista=list(reversed(lista))
    
    final=0
    exponente=0
    for i in lista:
        final+=int(i)*(8**exponente)

        exponente+=1

    print ("El resultado es: ", final)
    os.system('pause')


menu=["500","485","5445","277","Otro","SALIR" ]
    
def verMenu():
    
    os.system('cls')
    print("*****MENU PRINCIPAL*****")
    for i in range(len(menu)):
        print(f"{i+1}. {menu[i]}" )



result=True

while result:
    os.system('cls')
    verMenu()
    opc=input("Elija una opcion:")
    if opc=="1":
        pasaraHexa(500)
    elif opc=="2":
        pasaraHexa(5445)
    elif opc=="3":
        pasaraHexa(485)
    elif opc=="4":
        pasaraHexa(277)
    elif opc=="5":
        num=tryInt("Ingrese el numero decimal para convertir a hexadecimal: ")
        pasaraHexa(num)
    elif opc=="6":
        result=False
    else:
        print("No es valido")
        os.system('pause')
    
