import os


def tryInt(txt:str):#metodo para leer datos enteros
    isTry=True
    while isTry:
        try:
            x=int(input(txt))
        except:
            print("No es valido, ingrese nuevamente el dato")
            os.system('pause')
        else:
            isTry=False
            return x

def convertir(x):
    if x==10:
        return "A"
    elif x==11:
        return "B"
    elif x==12:
        return "C"
    elif x==13:
        return "D"
    elif x==14:
        return "E"
    elif x==15:
        return "F"    
    else:
        return str(x)

#numero=tryInt("Ingrese el numero decimal para convertir a hexadecimal")
def pasaraHexa(numero):
    os.system('cls')
    
    next=numero
    residuos=[]
    r=100
    while next>16:
        r=next%16
        next=next//16
        residuos.append(r)

    primero=convertir(next)
    residuos=list(reversed(residuos))
    final=primero
    
    for i in range(len(residuos)):
        final+=convertir(residuos[i])

    print ("El resultado es: ", final)
    os.system('pause')


menu=["611","48","5000","6199","Otro","SALIR" ]
    
def verMenu():
    
    os.system('cls')
    print("*****MENU PRINCIPAL*****")
    for i in range(len(menu)):
        print(f"{i+1}. {menu[i]}" )



result=True

while result:
    os.system('cls')
    verMenu()
    opc=input("Elija una opcion:")
    if opc=="1":
        pasaraHexa(611)
    elif opc=="2":
        pasaraHexa(48)
    elif opc=="3":
        pasaraHexa(5000)
    elif opc=="4":
        pasaraHexa(6199)
    elif opc=="5":
        num=tryInt("Ingrese el numero decimal para convertir a hexadecimal: ")
        pasaraHexa(num)
    elif opc=="6":
        result=False
    else:
        print("No es valido")
        os.system('pause')
    

